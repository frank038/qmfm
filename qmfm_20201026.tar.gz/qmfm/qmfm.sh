#!/bin/bash
thisdir=$(dirname "$0")
cd $thisdir
./qmfm.py
